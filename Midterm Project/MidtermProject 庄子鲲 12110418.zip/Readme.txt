This folder contains the project's report (midReport.pdf) and the source code. 
The dataset is generated within the code, with LR.ipynb containing the source code for logistic regression, and MLP.ipynb containing the source code for the Multilayer Perceptron (MLP). 
All test results are provided within the respective .ipynb files.
