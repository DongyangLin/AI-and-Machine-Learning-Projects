# AI and Machine Learning Fianl Project
12110418 庄子鲲

Include:

1. KMeans, SoftKMeans, both added non-local split-and-merge moves
2. PCA and Linear-Auto-Encoder
3. The Final Report in pdf form
4. Necessary datasets and test images
